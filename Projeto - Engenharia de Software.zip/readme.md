As ferramentas utilizadas para produção desse projeto foram as seguintes:

- Astah Community 7.2.0/1ff236 - Model versio: 37
- IntelliJ IDEA 2023.2 (Ultimate Edition)
- Google Documents