public class Tela {
    public void redirecionarPaginaLogin() {}
    public void redirecionarPaginaInicial() {}
}
