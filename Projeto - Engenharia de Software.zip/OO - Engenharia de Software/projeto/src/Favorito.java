public class Favorito {
    private String dataFavoritacao;

    public void criar() {}
}
