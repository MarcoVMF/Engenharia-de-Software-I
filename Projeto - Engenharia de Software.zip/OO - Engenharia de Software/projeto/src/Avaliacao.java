public class Avaliacao {
    private float nota;
    private String dataPublicacao;


    public void criar(float nota) {}
}
