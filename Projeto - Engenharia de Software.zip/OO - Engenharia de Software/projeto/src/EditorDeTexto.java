public class EditorDeTexto {
    private Livro livroAtual;
    private String caracteres;
    private int posicoes;


    public void adicionarCaracteres(String caracteres, int posicao) {}
    public void salvarProcessoUsuario(String conteudoLivro, String caracteres, int posicao) {}
    public void arquivarProcessoUsuario(String conteudoLivro, String caracteres, int posicao) {}
    public void excluirVersaoMaisAntiga() {}
    public void analisarOrtografia(Livro livro) {}
    public void sublinharErrosOrtografia(Livro livro) {}
    public void analisarSintaxe(Livro livro) {}
    public void sublinharErrosSintaxe(Livro livro) {}
}
