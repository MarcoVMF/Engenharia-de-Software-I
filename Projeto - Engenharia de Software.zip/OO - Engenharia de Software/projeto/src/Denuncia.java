public class Denuncia {
    private Livro livro;
    private String conteudoDenuncia;
    private String dataDenuncia;
}
