public class Erro {
    public void exibirMensagemErroCadastro() {}
    public void exibirMensagemErroLogin() {}
    public void exibirMensagemErroLogout() {}
    public void exibirMensagemErroPublicacao() {}
}
