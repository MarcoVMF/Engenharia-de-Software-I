public class Funcionario {
    private int nome;

    public void formularioParaFuncionario(Suporte suporte) {}
}
