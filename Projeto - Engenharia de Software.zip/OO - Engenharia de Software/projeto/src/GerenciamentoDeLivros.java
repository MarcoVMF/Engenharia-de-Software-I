public class GerenciamentoDeLivros {
    private Livro[] livrosCadastrados;


    public String buscarPalavrasChave(String palavraChave) {}
    public Livro inserirPalavrasChave(String palavraChave) {}
    public String escolherLivro(String nomeLivro) {}
    public String recuperarDetalhesLivro(String nomeLivro) {}
    public void validarDadosLivro(Livro livro) {}
    public void tornarLivroPublico(Livro livro) {}
    public void revisarDadosLivro(Livro livro) {}
    public void compartilharEmNovidades(Livro livro) {}
    public void validarTitulo(Livro livro) {}
    public void validarSinopse(Livro livro) {}
    public void validarGenero(Livro livro) {}
    public void validarNomeAutor(Livro livro) {}
}
