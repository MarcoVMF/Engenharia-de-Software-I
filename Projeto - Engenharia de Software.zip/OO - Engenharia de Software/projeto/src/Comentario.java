public class Comentario {
    private String conteudo;
    private String dataPublicacao;


    public void criar(String conteudo) {}
    public void validarComentario(String comentario) {}
    public void verificarPalavrasOfensivas(String comentario) {}
}
